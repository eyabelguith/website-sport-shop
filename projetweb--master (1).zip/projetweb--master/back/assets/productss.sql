CREATE TABLE `productss`
(`id` int(11) NOT NULL,
`brand` varchar(100) NOT NULL,
`category` varchar(50) NOT NULL,
`price` varchar(255) NOT NULL,
`description` varchar(50) NOT NULL,
`name` varchar(50) NOT NULL,
PRIMARY KEY (`id`));